<?php

$block_slug = 'uagb/modal-pro';

$block_data = array(
	'dynamic_assets' => array(
		'dir'        => 'modal-pro',
		'plugin-dir' => SPECTRA_PRO_DIR . '/',
	),
);
