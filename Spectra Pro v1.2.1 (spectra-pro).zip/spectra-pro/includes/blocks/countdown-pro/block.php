<?php

$block_slug = 'uagb/countdown-pro';

$block_data = array(
	'dynamic_assets' => array(
		'dir'        => 'countdown-pro',
		'plugin-dir' => SPECTRA_PRO_DIR . '/',
	),
);
