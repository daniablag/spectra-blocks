window.addEventListener( 'load', function() {
    setTimeout( function() {
        AOS.init();
    }, 0 );
} );
