<?php
/**
 * Single page settings page
 *
 * @package uag
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="uag-dashboard-app" class="uag-dashboard-app">
</div>
